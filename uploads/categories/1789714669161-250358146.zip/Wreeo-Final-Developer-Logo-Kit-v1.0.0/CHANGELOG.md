# Changelog

## 1.0.0 — 2026-09-17

- Established the final Wreeo Figtree Bold wordmark.
- Locked Wreeo Coral `#EB4A3A` and Light Warm Ivory `#FCFBF7`.
- Converted all lettering to self-contained vector outlines.
- Added coral, white, black, currentColor and background SVG masters.
- Added responsive PNG exports, favicon/ICO assets, app and PWA icons.
- Added Open Graph, X, LinkedIn, profile and email assets.
- Added HTML, CSS, SCSS, React, Next.js and Tailwind integration files.
- Added design tokens, documentation, manifest and checksums.
