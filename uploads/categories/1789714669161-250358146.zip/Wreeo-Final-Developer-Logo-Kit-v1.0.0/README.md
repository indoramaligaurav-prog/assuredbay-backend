# Wreeo Final Developer Logo Kit

Production-ready brand assets for the final Wreeo wordmark.

**Version:** 1.0.0  
**Primary master:** `master/vector/wreeo-logo-coral.svg`  
**Primary color:** Wreeo Coral `#EB4A3A` / `rgb(235 74 58)`  
**Primary background:** Light Warm Ivory `#FCFBF7` / `rgb(252 251 247)`

The master lettering is converted to vector outlines. Developers do not need to install or load a font to display the logo.

## Give these files to engineering

The simplest handoff is the entire ZIP. For a normal website implementation, engineers should copy everything from `web/public/` into the application's public/static directory and use:

- Header/footer: `wreeo-logo.svg`
- Dark or coral background: `wreeo-logo-white.svg`
- Compact UI: `wreeo-mark.svg`
- Browser icons: `favicon.ico`, `favicon.svg`, `apple-touch-icon.png`
- PWA: `site.webmanifest`, Android and maskable icons
- Social sharing: `wreeo-open-graph.png`

## Package map

| Folder | Contents |
|---|---|
| `master/vector/` | Coral, white, black, currentColor and background SVG masters |
| `master/raster/` | Transparent and background PNGs from 64–4096 px |
| `icons/favicon/` | SVG favicon, PNG sizes, ICO, Apple touch icon and browser metadata |
| `icons/app/` | Standard, maskable and reversed application icons |
| `icons/social/` | Open Graph, X, LinkedIn and profile artwork |
| `icons/email/` | Lightweight email-signature PNGs |
| `web/public/` | Copy-ready public-directory payload |
| `web/` | HTML, CSS, SCSS, React, Next.js and Tailwind examples |
| `tokens/` | JSON and CSS design tokens |
| `docs/` | Engineering specification, checklist, clear-space file and QA preview |
| `source/` | Reference reconstruction and provenance notes |

## Correct logo selection

- Use `wreeo-logo-coral.svg` on Warm Ivory, white and very pale neutral surfaces.
- Use `wreeo-logo-white.svg` on Wreeo Coral or dark photographic surfaces.
- Use `wreeo-logo-black.svg` only for one-color reproduction.
- Use the W mark only when the complete name is already established or space is constrained.
- Use PNG only when the platform cannot accept SVG.

## Minimum sizes

- Full wordmark: **120 CSS px** wide minimum.
- W mark: **24 CSS px** wide minimum.
- Printed wordmark: **25 mm** wide minimum.
- For Retina/high-density displays, use an image source at least twice the CSS display width.

## Clear space

Maintain clear space equal to one quarter of the capital height on every side. Use `docs/wreeo-logo-clearspace-template.svg` as the placement reference.

## Do not

- Do not retype, redraw or alter the wordmark.
- Do not use a different red, coral or cream value.
- Do not stretch, compress, rotate, outline or add effects.
- Do not apply gradients, shadows, glows or transparency.
- Do not place coral on a background with insufficient contrast.
- Do not crop the W or final `o`.

## Basic HTML

```html
<a href="/" aria-label="Wreeo home" class="wreeo-brand-link">
  <img
    src="/wreeo-logo.svg"
    width="3003"
    height="712"
    alt="Wreeo"
    class="wreeo-logo"
  >
</a>
```

Use the intrinsic width and height or the provided `aspect-ratio` CSS to prevent layout shift.

## Verification

- `asset-manifest.json` records dimensions, byte sizes and SHA-256 hashes.
- `SHA256SUMS.txt` verifies the delivered package after transfer.
- `docs/wreeo-final-kit-preview.png` is the visual QA board.

When the logo changes, issue a new version of the complete kit. Do not manually edit generated PNGs.
