import Foundation
import CoreText
import CoreGraphics

struct Outline {
    let path: String
    let bounds: CGRect
}

func number(_ value: CGFloat) -> String {
    var value = String(format: "%.3f", Double(value))
    while value.contains(".") && value.last == "0" { value.removeLast() }
    if value.last == "." { value.removeLast() }
    return value
}

func svgPath(_ path: CGPath) -> String {
    var commands: [String] = []
    path.applyWithBlock { pointer in
        let item = pointer.pointee
        switch item.type {
        case .moveToPoint:
            commands.append("M\(number(item.points[0].x)) \(number(item.points[0].y))")
        case .addLineToPoint:
            commands.append("L\(number(item.points[0].x)) \(number(item.points[0].y))")
        case .addQuadCurveToPoint:
            commands.append("Q\(number(item.points[0].x)) \(number(item.points[0].y)) \(number(item.points[1].x)) \(number(item.points[1].y))")
        case .addCurveToPoint:
            commands.append("C\(number(item.points[0].x)) \(number(item.points[0].y)) \(number(item.points[1].x)) \(number(item.points[1].y)) \(number(item.points[2].x)) \(number(item.points[2].y))")
        case .closeSubpath:
            commands.append("Z")
        @unknown default:
            break
        }
    }
    return commands.joined(separator: " ")
}

func outline(_ text: String, font: CTFont) -> Outline {
    let attributes = [kCTFontAttributeName as NSAttributedString.Key: font]
    let line = CTLineCreateWithAttributedString(NSAttributedString(string: text, attributes: attributes))
    let combined = CGMutablePath()
    for run in CTLineGetGlyphRuns(line) as! [CTRun] {
        let runFont = (CTRunGetAttributes(run) as NSDictionary)[kCTFontAttributeName] as! CTFont
        let count = CTRunGetGlyphCount(run)
        var glyphs = Array(repeating: CGGlyph(), count: count)
        var positions = Array(repeating: CGPoint.zero, count: count)
        CTRunGetGlyphs(run, CFRangeMake(0, count), &glyphs)
        CTRunGetPositions(run, CFRangeMake(0, count), &positions)
        for index in 0..<count {
            if let glyphPath = CTFontCreatePathForGlyph(runFont, glyphs[index], nil) {
                combined.addPath(glyphPath, transform: CGAffineTransform(translationX: positions[index].x, y: positions[index].y))
            }
        }
    }
    return Outline(path: svgPath(combined), bounds: combined.boundingBoxOfPath)
}

let workspace = URL(fileURLWithPath: "/Users/saadsheikh/Library/CloudStorage/OneDrive-shipmachineryparts.com/ecom site/00 all files imp", isDirectory: true)
let kit = workspace.appendingPathComponent("branding/wreeo/Wreeo-Final-Developer-Logo-Kit-v1.0.0", isDirectory: true)
let vectorDirectory = kit.appendingPathComponent("master/vector", isDirectory: true)
let faviconDirectory = kit.appendingPathComponent("icons/favicon", isDirectory: true)
let appDirectory = kit.appendingPathComponent("icons/app", isDirectory: true)
let docsDirectory = kit.appendingPathComponent("docs", isDirectory: true)
let fontURL = workspace.appendingPathComponent("branding/wreeo/font-variations/fonts/Figtree-wght.ttf")

for directory in [vectorDirectory, faviconDirectory, appDirectory, docsDirectory] {
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
}

CTFontManagerRegisterFontsForURL(fontURL as CFURL, .process, nil)
let font = CTFontCreateWithName("Figtree-Bold" as CFString, 1000, nil)
let logo = outline("Wreeo", font: font)
let mark = outline("W", font: font)

let coral = "#EB4A3A"
let ivory = "#FCFBF7"
let black = "#111111"
let dark = "#211B19"
let logoWidth = logo.bounds.width
let logoHeight = logo.bounds.height
let markWidth = mark.bounds.width
let markHeight = mark.bounds.height
let logoTransform = "translate(\(number(-logo.bounds.minX)) \(number(logo.bounds.maxY))) scale(1 -1)"
let markTransform = "translate(\(number(-mark.bounds.minX)) \(number(mark.bounds.maxY))) scale(1 -1)"
let clearSpace: CGFloat = 175

func svg(viewBox: String, title: String, body: String, width: CGFloat? = nil, height: CGFloat? = nil) -> String {
    let dimensions: String
    if let width, let height {
        dimensions = " width=\"\(number(width))\" height=\"\(number(height))\""
    } else {
        dimensions = ""
    }
    return """
    <svg xmlns="http://www.w3.org/2000/svg"\(dimensions) viewBox="\(viewBox)" role="img" aria-label="\(title)" shape-rendering="geometricPrecision">
      <title>\(title)</title>
      \(body)
    </svg>
    """
}

func logoArtwork(fill: String) -> String {
    "<g transform=\"\(logoTransform)\"><path d=\"\(logo.path)\" fill=\"\(fill)\"/></g>"
}

func markArtwork(fill: String) -> String {
    "<g transform=\"\(markTransform)\"><path d=\"\(mark.path)\" fill=\"\(fill)\"/></g>"
}

func write(_ directory: URL, _ name: String, _ value: String) throws {
    try value.write(to: directory.appendingPathComponent(name), atomically: true, encoding: .utf8)
}

let logoViewBox = "0 0 \(number(logoWidth)) \(number(logoHeight))"
let markViewBox = "0 0 \(number(markWidth)) \(number(markHeight))"

try write(vectorDirectory, "wreeo-logo-coral.svg", svg(
    viewBox: logoViewBox,
    title: "Wreeo",
    body: logoArtwork(fill: coral),
    width: logoWidth,
    height: logoHeight
))

try write(vectorDirectory, "wreeo-logo-white.svg", svg(
    viewBox: logoViewBox,
    title: "Wreeo white logo",
    body: logoArtwork(fill: "#FFFFFF"),
    width: logoWidth,
    height: logoHeight
))

try write(vectorDirectory, "wreeo-logo-black.svg", svg(
    viewBox: logoViewBox,
    title: "Wreeo black logo",
    body: logoArtwork(fill: black),
    width: logoWidth,
    height: logoHeight
))

try write(vectorDirectory, "wreeo-logo-currentcolor.svg", svg(
    viewBox: logoViewBox,
    title: "Wreeo currentColor logo",
    body: logoArtwork(fill: "currentColor"),
    width: logoWidth,
    height: logoHeight
))

let backgroundWidth = logoWidth + clearSpace * 2
let backgroundHeight = logoHeight + clearSpace * 2
let coralOnIvory = """
<rect width="\(number(backgroundWidth))" height="\(number(backgroundHeight))" rx="48" fill="\(ivory)"/>
<g transform="translate(\(number(clearSpace)) \(number(clearSpace)))">\(logoArtwork(fill: coral))</g>
"""
try write(vectorDirectory, "wreeo-logo-coral-on-ivory.svg", svg(
    viewBox: "0 0 \(number(backgroundWidth)) \(number(backgroundHeight))",
    title: "Wreeo coral logo on warm ivory",
    body: coralOnIvory,
    width: backgroundWidth,
    height: backgroundHeight
))

let whiteOnCoral = """
<rect width="\(number(backgroundWidth))" height="\(number(backgroundHeight))" rx="48" fill="\(coral)"/>
<g transform="translate(\(number(clearSpace)) \(number(clearSpace)))">\(logoArtwork(fill: "#FFFFFF"))</g>
"""
try write(vectorDirectory, "wreeo-logo-white-on-coral.svg", svg(
    viewBox: "0 0 \(number(backgroundWidth)) \(number(backgroundHeight))",
    title: "Wreeo white logo on coral",
    body: whiteOnCoral,
    width: backgroundWidth,
    height: backgroundHeight
))

for (name, fill, title) in [
    ("wreeo-mark-coral.svg", coral, "Wreeo coral W mark"),
    ("wreeo-mark-white.svg", "#FFFFFF", "Wreeo white W mark"),
    ("wreeo-mark-black.svg", black, "Wreeo black W mark"),
    ("wreeo-mark-currentcolor.svg", "currentColor", "Wreeo currentColor W mark")
] {
    try write(vectorDirectory, name, svg(
        viewBox: markViewBox,
        title: title,
        body: markArtwork(fill: fill),
        width: markWidth,
        height: markHeight
    ))
}

let clearspaceTemplate = """
<rect x="0" y="0" width="\(number(backgroundWidth))" height="\(number(backgroundHeight))" fill="\(ivory)"/>
<rect x="1" y="1" width="\(number(backgroundWidth - 2))" height="\(number(backgroundHeight - 2))" fill="none" stroke="#B8AFAA" stroke-width="4" stroke-dasharray="20 16"/>
<g transform="translate(\(number(clearSpace)) \(number(clearSpace)))">\(logoArtwork(fill: coral))</g>
"""
try write(docsDirectory, "wreeo-logo-clearspace-template.svg", svg(
    viewBox: "0 0 \(number(backgroundWidth)) \(number(backgroundHeight))",
    title: "Wreeo logo clear-space template",
    body: clearspaceTemplate,
    width: backgroundWidth,
    height: backgroundHeight
))

// Square favicon: coral W on locked warm ivory.
let faviconScale: CGFloat = 50 / markWidth
let faviconHeight = markHeight * faviconScale
let faviconX: CGFloat = 7
let faviconY = (64 - faviconHeight) / 2
let faviconBody = """
<rect width="64" height="64" fill="\(ivory)"/>
<g transform="translate(\(number(faviconX)) \(number(faviconY))) scale(\(number(faviconScale)))">\(markArtwork(fill: coral))</g>
"""
try write(faviconDirectory, "favicon.svg", svg(
    viewBox: "0 0 64 64",
    title: "Wreeo favicon",
    body: faviconBody,
    width: 64,
    height: 64
))

let safariScale: CGFloat = 52 / markWidth
let safariY = (64 - markHeight * safariScale) / 2
let safariBody = """
<g transform="translate(6 \(number(safariY))) scale(\(number(safariScale)))">\(markArtwork(fill: "#000000"))</g>
"""
try write(faviconDirectory, "safari-pinned-tab.svg", svg(
    viewBox: "0 0 64 64",
    title: "Wreeo Safari pinned tab",
    body: safariBody,
    width: 64,
    height: 64
))

// App-store artwork is square; operating systems apply their own masks.
let appScale: CGFloat = 720 / markWidth
let appX: CGFloat = 152
let appY = (1024 - markHeight * appScale) / 2
let appBody = """
<rect width="1024" height="1024" fill="\(ivory)"/>
<g transform="translate(\(number(appX)) \(number(appY))) scale(\(number(appScale)))">\(markArtwork(fill: coral))</g>
"""
try write(appDirectory, "wreeo-app-icon.svg", svg(
    viewBox: "0 0 1024 1024",
    title: "Wreeo application icon",
    body: appBody,
    width: 1024,
    height: 1024
))

let maskableScale: CGFloat = 610 / markWidth
let maskableX: CGFloat = 207
let maskableY = (1024 - markHeight * maskableScale) / 2
let maskableBody = """
<rect width="1024" height="1024" fill="\(ivory)"/>
<g transform="translate(\(number(maskableX)) \(number(maskableY))) scale(\(number(maskableScale)))">\(markArtwork(fill: coral))</g>
"""
try write(appDirectory, "wreeo-maskable-icon.svg", svg(
    viewBox: "0 0 1024 1024",
    title: "Wreeo maskable application icon",
    body: maskableBody,
    width: 1024,
    height: 1024
))

let reversedAppBody = """
<rect width="1024" height="1024" fill="\(coral)"/>
<g transform="translate(\(number(appX)) \(number(appY))) scale(\(number(appScale)))">\(markArtwork(fill: "#FFFFFF"))</g>
"""
try write(appDirectory, "wreeo-app-icon-reversed.svg", svg(
    viewBox: "0 0 1024 1024",
    title: "Wreeo reversed application icon",
    body: reversedAppBody,
    width: 1024,
    height: 1024
))

print("Wreeo final vectors generated. Logo \(number(logoWidth)) × \(number(logoHeight)); mark \(number(markWidth)) × \(number(markHeight)); coral \(coral); ivory \(ivory).")
