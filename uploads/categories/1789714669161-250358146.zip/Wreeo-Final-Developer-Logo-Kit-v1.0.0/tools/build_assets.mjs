import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {createRequire} from 'node:module';

const require = createRequire(import.meta.url);
const sharp = require('/Users/saadsheikh/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/sharp');

const workspace = '/Users/saadsheikh/Library/CloudStorage/OneDrive-shipmachineryparts.com/ecom site/00 all files imp';
const kit = path.join(workspace, 'branding/wreeo/Wreeo-Final-Developer-Logo-Kit-v1.0.0');
const vector = path.join(kit, 'master/vector');
const raster = path.join(kit, 'master/raster');
const favicon = path.join(kit, 'icons/favicon');
const app = path.join(kit, 'icons/app');
const social = path.join(kit, 'icons/social');
const email = path.join(kit, 'icons/email');
const docs = path.join(kit, 'docs');
const source = path.join(kit, 'source');
const publicDirectory = path.join(kit, 'web/public');

const coral = '#EB4A3A';
const ivory = '#FCFBF7';
const ink = '#211B19';
const png = {compressionLevel: 9, adaptiveFiltering: true, palette: false};

for (const directory of [raster, favicon, app, social, email, docs, source, publicDirectory]) {
  await fs.mkdir(directory, {recursive: true});
}

async function renderSvg(input, output, width) {
  await sharp(input, {density: 320})
    .resize({width, withoutEnlargement: false})
    .png(png)
    .toFile(output);
}

const logoVariants = {
  coral: 'wreeo-logo-coral.svg',
  white: 'wreeo-logo-white.svg',
  black: 'wreeo-logo-black.svg',
};

for (const width of [256, 512, 1024, 2048, 4096]) {
  await renderSvg(
    path.join(vector, logoVariants.coral),
    path.join(raster, `wreeo-logo-coral-transparent-${width}w.png`),
    width
  );
}

for (const variant of ['white', 'black']) {
  for (const width of [512, 1024, 2048]) {
    await renderSvg(
      path.join(vector, logoVariants[variant]),
      path.join(raster, `wreeo-logo-${variant}-transparent-${width}w.png`),
      width
    );
  }
}

for (const width of [512, 1024, 2048]) {
  await renderSvg(
    path.join(vector, 'wreeo-logo-coral-on-ivory.svg'),
    path.join(raster, `wreeo-logo-coral-on-ivory-${width}w.png`),
    width
  );
  await renderSvg(
    path.join(vector, 'wreeo-logo-white-on-coral.svg'),
    path.join(raster, `wreeo-logo-white-on-coral-${width}w.png`),
    width
  );
}

for (const width of [64, 128, 256, 512, 1024]) {
  await renderSvg(
    path.join(vector, 'wreeo-mark-coral.svg'),
    path.join(raster, `wreeo-mark-coral-transparent-${width}w.png`),
    width
  );
}

for (const size of [16, 32, 48]) {
  await renderSvg(path.join(favicon, 'favicon.svg'), path.join(favicon, `favicon-${size}x${size}.png`), size);
}

await renderSvg(path.join(app, 'wreeo-app-icon.svg'), path.join(favicon, 'apple-touch-icon.png'), 180);
await renderSvg(path.join(app, 'wreeo-app-icon.svg'), path.join(favicon, 'mstile-150x150.png'), 150);

for (const size of [192, 512, 1024]) {
  await renderSvg(path.join(app, 'wreeo-app-icon.svg'), path.join(app, `wreeo-app-icon-${size}x${size}.png`), size);
}
for (const size of [192, 512, 1024]) {
  await renderSvg(path.join(app, 'wreeo-maskable-icon.svg'), path.join(app, `wreeo-maskable-icon-${size}x${size}.png`), size);
}
await renderSvg(path.join(app, 'wreeo-app-icon-reversed.svg'), path.join(app, 'wreeo-app-icon-reversed-1024x1024.png'), 1024);

async function makeIco(files, destination) {
  const images = await Promise.all(files.map(file => fs.readFile(file)));
  const header = Buffer.alloc(6);
  header.writeUInt16LE(0, 0);
  header.writeUInt16LE(1, 2);
  header.writeUInt16LE(images.length, 4);
  const directory = Buffer.alloc(16 * images.length);
  let offset = 6 + directory.length;
  images.forEach((image, index) => {
    const size = Number(path.basename(files[index]).match(/favicon-(\d+)x/)[1]);
    const base = index * 16;
    directory.writeUInt8(size, base);
    directory.writeUInt8(size, base + 1);
    directory.writeUInt8(0, base + 2);
    directory.writeUInt8(0, base + 3);
    directory.writeUInt16LE(1, base + 4);
    directory.writeUInt16LE(32, base + 6);
    directory.writeUInt32LE(image.length, base + 8);
    directory.writeUInt32LE(offset, base + 12);
    offset += image.length;
  });
  await fs.writeFile(destination, Buffer.concat([header, directory, ...images]));
}

await makeIco(
  [16, 32, 48].map(size => path.join(favicon, `favicon-${size}x${size}.png`)),
  path.join(favicon, 'favicon.ico')
);

async function centeredLogoCanvas({width, height, background, logoFile, logoWidth, output}) {
  const logo = await sharp(path.join(vector, logoFile), {density: 320}).resize({width: logoWidth}).png().toBuffer();
  await sharp({create: {width, height, channels: 4, background}})
    .composite([{input: logo, gravity: 'center'}])
    .png(png)
    .toFile(output);
}

await centeredLogoCanvas({
  width: 1200, height: 630, background: ivory, logoFile: 'wreeo-logo-coral.svg', logoWidth: 900,
  output: path.join(social, 'wreeo-open-graph-1200x630.png'),
});
await centeredLogoCanvas({
  width: 1200, height: 630, background: coral, logoFile: 'wreeo-logo-white.svg', logoWidth: 900,
  output: path.join(social, 'wreeo-open-graph-reversed-1200x630.png'),
});
await centeredLogoCanvas({
  width: 1200, height: 600, background: ivory, logoFile: 'wreeo-logo-coral.svg', logoWidth: 880,
  output: path.join(social, 'wreeo-x-card-1200x600.png'),
});
await centeredLogoCanvas({
  width: 1200, height: 627, background: ivory, logoFile: 'wreeo-logo-coral.svg', logoWidth: 880,
  output: path.join(social, 'wreeo-linkedin-1200x627.png'),
});
await fs.copyFile(path.join(app, 'wreeo-app-icon-1024x1024.png'), path.join(social, 'wreeo-profile-1024x1024.png'));

for (const width of [300, 600]) {
  await renderSvg(path.join(vector, 'wreeo-logo-coral.svg'), path.join(email, `wreeo-email-logo-transparent-${width}w.png`), width);
}
await renderSvg(path.join(vector, 'wreeo-logo-coral-on-ivory.svg'), path.join(email, 'wreeo-email-logo-ivory-600w.png'), 600);

// Rebuilt reference board corresponding to the supplied final visual.
const referenceLogo = await sharp(path.join(vector, 'wreeo-logo-coral.svg'), {density: 320}).resize({width: 1150}).png().toBuffer();
const referenceFrame = Buffer.from(`
<svg xmlns="http://www.w3.org/2000/svg" width="1408" height="1117">
  <rect width="1408" height="1117" fill="${ivory}"/>
  <rect x="18" y="35" width="1372" height="1028" rx="48" fill="none" stroke="#E2DDD7" stroke-width="2"/>
</svg>`);
await sharp(referenceFrame)
  .composite([{input: referenceLogo, left: 129, top: 425}])
  .png(png)
  .toFile(path.join(source, 'wreeo-final-reference-rebuilt.png'));

// Copy-ready public folder.
for (const [from, to] of [
  [path.join(vector, 'wreeo-logo-coral.svg'), path.join(publicDirectory, 'wreeo-logo.svg')],
  [path.join(vector, 'wreeo-logo-white.svg'), path.join(publicDirectory, 'wreeo-logo-white.svg')],
  [path.join(vector, 'wreeo-logo-black.svg'), path.join(publicDirectory, 'wreeo-logo-black.svg')],
  [path.join(vector, 'wreeo-mark-coral.svg'), path.join(publicDirectory, 'wreeo-mark.svg')],
  [path.join(vector, 'wreeo-mark-white.svg'), path.join(publicDirectory, 'wreeo-mark-white.svg')],
  [path.join(vector, 'wreeo-mark-black.svg'), path.join(publicDirectory, 'wreeo-mark-black.svg')],
  [path.join(favicon, 'favicon.svg'), path.join(publicDirectory, 'favicon.svg')],
  [path.join(favicon, 'favicon.ico'), path.join(publicDirectory, 'favicon.ico')],
  [path.join(favicon, 'apple-touch-icon.png'), path.join(publicDirectory, 'apple-touch-icon.png')],
  [path.join(favicon, 'safari-pinned-tab.svg'), path.join(publicDirectory, 'safari-pinned-tab.svg')],
  [path.join(favicon, 'mstile-150x150.png'), path.join(publicDirectory, 'mstile-150x150.png')],
  [path.join(favicon, 'site.webmanifest'), path.join(publicDirectory, 'site.webmanifest')],
  [path.join(favicon, 'browserconfig.xml'), path.join(publicDirectory, 'browserconfig.xml')],
  [path.join(app, 'wreeo-app-icon-192x192.png'), path.join(publicDirectory, 'android-chrome-192x192.png')],
  [path.join(app, 'wreeo-app-icon-512x512.png'), path.join(publicDirectory, 'android-chrome-512x512.png')],
  [path.join(app, 'wreeo-maskable-icon-512x512.png'), path.join(publicDirectory, 'wreeo-maskable-512x512.png')],
  [path.join(social, 'wreeo-open-graph-1200x630.png'), path.join(publicDirectory, 'wreeo-open-graph.png')],
]) {
  await fs.copyFile(from, to);
}

// Visual QA board.
const primary = await sharp(path.join(vector, 'wreeo-logo-coral.svg'), {density: 320}).resize({width: 1080}).png().toBuffer();
const reversed = await sharp(path.join(vector, 'wreeo-logo-white.svg'), {density: 320}).resize({width: 780}).png().toBuffer();
const mono = await sharp(path.join(vector, 'wreeo-logo-black.svg'), {density: 320}).resize({width: 780}).png().toBuffer();
const icon = await sharp(path.join(app, 'wreeo-app-icon.svg'), {density: 320}).resize({width: 330}).png().toBuffer();
const qaFrame = Buffer.from(`
<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1200">
  <rect width="1600" height="1200" fill="#F3F0EB"/>
  <text x="90" y="88" font-family="Arial, sans-serif" font-size="46" font-weight="700" fill="${ink}">Wreeo final developer logo kit</text>
  <text x="90" y="134" font-family="Arial, sans-serif" font-size="24" fill="#716965">Coral #EB4A3A · Warm Ivory #FCFBF7</text>
  <rect x="70" y="180" width="1460" height="320" rx="34" fill="${ivory}"/>
  <rect x="70" y="540" width="940" height="260" rx="34" fill="${coral}"/>
  <rect x="70" y="840" width="940" height="260" rx="34" fill="#FFFFFF"/>
  <rect x="1050" y="540" width="480" height="560" rx="34" fill="#E8E2DC"/>
  <rect x="1110" y="600" width="150" height="150" rx="20" fill="${coral}"/>
  <text x="1110" y="785" font-family="Arial, sans-serif" font-size="22" font-weight="700" fill="${ink}">Wreeo Coral</text>
  <text x="1110" y="817" font-family="monospace" font-size="20" fill="#716965">#EB4A3A</text>
  <rect x="1320" y="600" width="150" height="150" rx="20" fill="${ivory}" stroke="#D8D1CA"/>
  <text x="1288" y="785" font-family="Arial, sans-serif" font-size="22" font-weight="700" fill="${ink}">Warm Ivory</text>
  <text x="1308" y="817" font-family="monospace" font-size="20" fill="#716965">#FCFBF7</text>
</svg>`);
await sharp(qaFrame)
  .composite([
    {input: primary, left: 260, top: 220},
    {input: reversed, left: 150, top: 575},
    {input: mono, left: 150, top: 875},
    {input: icon, left: 1125, top: 835},
  ])
  .png(png)
  .toFile(path.join(docs, 'wreeo-final-kit-preview.png'));

async function walk(directory) {
  const files = [];
  for (const entry of await fs.readdir(directory, {withFileTypes: true})) {
    if (entry.name === '.DS_Store') continue;
    const file = path.join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await walk(file));
    else files.push(file);
  }
  return files;
}

const files = (await walk(kit)).filter(file =>
  path.basename(file) !== 'asset-manifest.json' && path.basename(file) !== 'SHA256SUMS.txt'
);
const assets = [];
for (const file of files) {
  const relative = path.relative(kit, file);
  const stat = await fs.stat(file);
  const hash = crypto.createHash('sha256').update(await fs.readFile(file)).digest('hex');
  const item = {file: relative, bytes: stat.size, sha256: hash};
  if (/\.(png|svg|ico)$/i.test(file)) {
    try {
      const metadata = await sharp(file).metadata();
      if (metadata.width && metadata.height) item.dimensions = `${metadata.width}x${metadata.height}`;
    } catch {}
  }
  assets.push(item);
}

await fs.writeFile(path.join(kit, 'asset-manifest.json'), JSON.stringify({
  name: 'Wreeo Final Developer Logo Kit',
  version: '1.0.0',
  productionColors: {
    coral: {hex: coral, rgb: [235, 74, 58]},
    warmIvory: {hex: ivory, rgb: [252, 251, 247]},
  },
  master: 'master/vector/wreeo-logo-coral.svg',
  generatedAt: new Date().toISOString(),
  assetCount: assets.length,
  assets,
}, null, 2) + '\n');

const checksumFiles = (await walk(kit))
  .filter(file => path.basename(file) !== 'SHA256SUMS.txt')
  .sort((a, b) => path.relative(kit, a).localeCompare(path.relative(kit, b)));
const checksums = [];
for (const file of checksumFiles) {
  const hash = crypto.createHash('sha256').update(await fs.readFile(file)).digest('hex');
  checksums.push(`${hash}  ${path.relative(kit, file)}`);
}
await fs.writeFile(path.join(kit, 'SHA256SUMS.txt'), checksums.join('\n') + '\n');

console.log(`Built ${assets.length} Wreeo final-kit files.`);
