import type { ImgHTMLAttributes } from 'react';

type WreeoLogoProps = Omit<ImgHTMLAttributes<HTMLImageElement>, 'src' | 'alt'> & {
  variant?: 'coral' | 'white' | 'black';
  markOnly?: boolean;
  decorative?: boolean;
  assetBase?: string;
};

export function WreeoLogo({
  variant = 'coral',
  markOnly = false,
  decorative = false,
  assetBase = '',
  width,
  height,
  ...props
}: WreeoLogoProps) {
  const file = markOnly
    ? variant === 'coral' ? 'wreeo-mark.svg' : `wreeo-mark-${variant}.svg`
    : variant === 'coral' ? 'wreeo-logo.svg' : `wreeo-logo-${variant}.svg`;
  const intrinsic = markOnly
    ? {width: width ?? 968, height: height ?? 700}
    : {width: width ?? 3003, height: height ?? 712};

  return (
    <img
      {...props}
      {...intrinsic}
      src={`${assetBase}/${file}`}
      alt={decorative ? '' : 'Wreeo'}
      aria-hidden={decorative || undefined}
      decoding="async"
      draggable={false}
    />
  );
}
