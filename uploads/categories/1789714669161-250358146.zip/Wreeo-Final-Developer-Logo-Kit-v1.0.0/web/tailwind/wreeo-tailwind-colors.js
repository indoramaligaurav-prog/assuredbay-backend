/** Merge this object into theme.extend.colors. */
module.exports = {
  wreeo: {
    coral: '#EB4A3A',
    ivory: '#FCFBF7',
    ink: '#211B19',
  },
};
