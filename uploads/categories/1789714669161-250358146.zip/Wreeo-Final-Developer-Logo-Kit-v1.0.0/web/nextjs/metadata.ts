import type {Metadata, Viewport} from 'next';

export const metadata: Metadata = {
  applicationName: 'Wreeo',
  title: {
    default: 'Wreeo',
    template: '%s | Wreeo',
  },
  manifest: '/site.webmanifest',
  icons: {
    icon: [
      {url: '/favicon.ico', sizes: 'any'},
      {url: '/favicon.svg', type: 'image/svg+xml'},
    ],
    apple: '/apple-touch-icon.png',
  },
  openGraph: {
    type: 'website',
    siteName: 'Wreeo',
    title: 'Wreeo',
    images: [{url: '/wreeo-open-graph.png', width: 1200, height: 630, alt: 'Wreeo'}],
  },
  twitter: {
    card: 'summary_large_image',
    images: ['/wreeo-open-graph.png'],
  },
};

export const viewport: Viewport = {
  themeColor: [
    {media: '(prefers-color-scheme: light)', color: '#FCFBF7'},
    {media: '(prefers-color-scheme: dark)', color: '#EB4A3A'},
  ],
};
