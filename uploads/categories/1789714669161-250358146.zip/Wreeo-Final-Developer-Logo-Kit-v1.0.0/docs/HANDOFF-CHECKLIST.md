# Developer handoff checklist

- [ ] Copy `web/public/` into the application's public/static directory.
- [ ] Add `web/html/head.html` to the document head.
- [ ] Replace all `example.com` URLs with production absolute URLs.
- [ ] Use `wreeo-logo.svg` in the site header and footer.
- [ ] Use explicit `width` and `height` attributes to prevent layout shift.
- [ ] Confirm the white logo variant on coral and dark surfaces.
- [ ] Confirm 16 px, 32 px and 48 px favicons in supported browsers.
- [ ] Confirm Apple touch, Android and maskable icons on real devices.
- [ ] Confirm Open Graph previews using the production URL.
- [ ] Confirm the manifest scope and start URL for the deployed application.
- [ ] Verify CDN cache headers and cache invalidation.
- [ ] Run `shasum -a 256 -c SHA256SUMS.txt` after transfer.
