# Wreeo engineering specification

## Locked colors

| Token | HEX | RGB | Intended use |
|---|---|---|---|
| Wreeo Coral | `#EB4A3A` | `235, 74, 58` | Primary wordmark, mark, buttons and brand accents |
| Light Warm Ivory | `#FCFBF7` | `252, 251, 247` | Primary brand background |

Do not substitute browser-named colors, approximate reds or generic off-whites.

## Master geometry

- Wordmark viewBox: `0 0 3002.974 712`
- Wordmark aspect ratio: approximately `4.21766:1`
- Mark viewBox: `0 0 968.391 700`
- Mark aspect ratio: approximately `1.38342:1`
- Lettering: Figtree Bold 700 converted to paths
- Default file: `master/vector/wreeo-logo-coral.svg`

## Accessibility

- Linked header logo: accessible name `Wreeo home`.
- Informational logo: `alt="Wreeo"`.
- Decorative repeat: `alt=""` and `aria-hidden="true"`.
- Do not rely on Wreeo Coral alone to communicate application state.
- Check text contrast separately; the logo colors are not body-text tokens.

## Clear space and minimum size

Maintain 175 master units around the wordmark, equal to one quarter of its capital height. Minimum digital widths are 120 px for the wordmark and 24 px for the mark.

## Rendering

- Prefer SVG for browsers and software that renders SVG reliably.
- Set explicit intrinsic dimensions to avoid cumulative layout shift.
- Keep `height: auto` whenever CSS controls width.
- Do not apply CSS `filter`, `opacity`, `mix-blend-mode` or `transform` to the logo.
- If SVG uploads are blocked, use the smallest PNG at least twice the CSS display size.

## Application icons

- Standard app icons use Coral on Warm Ivory.
- Do not add rounded corners to iOS source artwork; iOS applies its own mask.
- Use the dedicated maskable icon for Android/PWA `purpose: maskable`.
- Do not generate favicons from the full wordmark; use the supplied W mark assets.

## Social previews

Use the 1200×630 Open Graph PNG with absolute HTTPS metadata URLs. Do not use transparent logos directly as sharing images.

## Caching

Serve logo SVGs and PNGs with long-lived immutable caching when filenames are versioned. Keep `/favicon.ico` and `/site.webmanifest` at stable paths. Purge the CDN when the kit version changes.
