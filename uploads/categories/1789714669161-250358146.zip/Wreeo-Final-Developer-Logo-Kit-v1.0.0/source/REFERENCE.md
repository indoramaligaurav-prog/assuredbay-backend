# Final reference

The production wordmark is the final `Wreeo` artwork shown in the supplied conversation image, rebuilt as Figtree Bold vector outlines using the explicitly approved production colors:

- Wreeo Coral: `#EB4A3A` / `rgb(235, 74, 58)`
- Light Warm Ivory: `#FCFBF7` / `rgb(252, 251, 247)`

The attachment's referenced Downloads path was unavailable to the local build process, so `wreeo-final-reference-rebuilt.png` is the controlled high-resolution reconstruction generated from the outlined production master. All implementation assets are generated from the SVG master, not from a screenshot.
