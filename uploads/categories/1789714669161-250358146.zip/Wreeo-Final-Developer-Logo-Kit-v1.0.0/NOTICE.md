# Asset notice

This package contains the proprietary Wreeo identity supplied for authorized use by Wreeo's employees, engineers, contractors and production vendors. Trademark clearance and registration remain the responsibility of the brand owner.

The production SVG masters contain outlined lettering and have no runtime font dependency. Figtree's open-font license is retained in `source/` for provenance.
